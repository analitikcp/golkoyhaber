# GölköyHaber Android APK

GölköyHaber'in bağımsız Android uygulama projesidir.

## GitHub APK derleme

1. Repository köküne bu paketin içindeki dosyaları yükleyin.
2. GitHub'da **Actions** sekmesine girin.
3. **GolkoyHaber APK** workflow'unu seçin.
4. **Run workflow** ile çalıştırın.
5. Oluşan `GolkoyHaber-debug` artifact'ından APK'yı indirin.

## Mevcut yapı

- Uygulama adı: GölköyHaber
- Application ID: `com.golkoyhaber.app`
- Launcher ikonu: GölköyHaber + yeşil fındık logosu
- Facebook yayın hedefi: `https://www.facebook.com/habergolkoy52`
- Kategoriler: Gölköy, Resmî, Asayiş, Eğitim, Sağlık, Spor, Tarım, Siyaset, Hava, Vefat

## Mimari yön

Kaynaklar → Haber Motoru → Filtre/Mükerrer Kontrol → Editör Onayı → APK + Web + Facebook Sayfası

Facebook erişim tokenları APK içine konulmamalıdır. Otomatik Facebook yayınlama backend üzerinden yapılacaktır.


## 10 yeni Ordu haber kaynağı

Uygulama artık mevcut 4 kaynağa ek olarak şu 10 kaynağı tarar:

1. İHA Ordu
2. Haberler.com Ordu
3. DHA Ordu
4. Habertürk Yerel Ordu
5. SonDakika.com Ordu
6. NTV Ordu
7. CNN Türk Ordu
8. Google News Ordu
9. Ordu Büyükşehir Belediyesi
10. TRT Haber Ordu

Toplam canlı kaynak: 14. Her kaynak için en fazla 15 içerik alınır; ortak akış en fazla 60 haber gösterir.

### Tarih filtresi

Yalnızca **bugün veya dün yayımlanan** ve yayın tarihi tespit edilebilen içerikler kabul edilir. Daha eski, gelecek tarihli veya tarihi çözülemeyen içerikler elenir. Detay sayfalarında mümkün olduğunda `time`, `article:published_time`, `datePublished` ve yayın tarihi alanları kullanılır. Güncelleme tarihi yayın tarihi yerine kullanılmaz.

### Facebook paylaşımı

Haber kartlarında `Facebook'ta Paylaş` düğmesi bulunur ve Facebook paylaşım ekranını açar. Üstteki Facebook düğmesi ise GölköyHaber Facebook Sayfasını açar. Sayfaya tamamen otomatik yayın için Page Access Token'ın APK'ye gömülmesi güvenli değildir; bunun için sunucu tarafında Meta Graph API entegrasyonu gerekir.
