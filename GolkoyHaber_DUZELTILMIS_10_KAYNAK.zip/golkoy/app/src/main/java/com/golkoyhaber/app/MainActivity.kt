package com.golkoyhaber.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.google.android.material.button.MaterialButton
import org.jsoup.Jsoup
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

private data class News(
    val category: String,
    val title: String,
    val summary: String,
    val source: String,
    val url: String,
    val publishedAt: Date
)

private data class SourceConfig(
    val name: String,
    val url: String,
    val category: String,
    val host: String,
    val kind: String = "generic"
)

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: NewsAdapter
    private lateinit var status: TextView
    private val executor = Executors.newFixedThreadPool(4)
    private var allNews: List<News> = emptyList()

    private val sources = listOf(
        SourceConfig("Ordu Valiliği", "https://www.ordu.gov.tr/", "Resmî Kurumlar", "ordu.gov.tr"),
        SourceConfig("Gölköy Kaymakamlığı", "https://www.golkoy.gov.tr/haberler", "Gölköy", "golkoy.gov.tr"),
        SourceConfig("Gölköy Belediyesi", "https://www.golkoy.bel.tr/", "Gölköy", "golkoy.bel.tr"),
        SourceConfig("Gölköy İlçe Millî Eğitim", "https://golkoy.meb.gov.tr/", "Eğitim", "golkoy.meb.gov.tr"),
        SourceConfig("İHA Ordu", "https://www.iha.com.tr/ordu", "Ordu", "iha.com.tr", "iha"),
        SourceConfig("Haberler.com Ordu", "https://www.haberler.com/ordu/", "Ordu", "haberler.com", "haberler"),
        SourceConfig("DHA Ordu", "https://www.dha.com.tr/ordu-haber/", "Ordu", "dha.com.tr", "dha"),
        SourceConfig("Habertürk Yerel Ordu", "https://yerel-haberler.haberturk.com/ordu-haberleri", "Ordu", "haberturk.com", "haberturk"),
        SourceConfig("SonDakika.com Ordu", "https://www.sondakika.com/ordu/", "Ordu", "sondakika.com", "sondakika"),
        SourceConfig("NTV Ordu", "https://www.ntv.com.tr/haberleri/ordu", "Ordu", "ntv.com.tr", "ntv"),
        SourceConfig("CNN Türk Ordu", "https://www.cnnturk.com/ordu-haber/", "Ordu", "cnnturk.com", "cnnturk"),
        SourceConfig("Google News Ordu", "https://news.google.com/topics/CAAqHAgKIhZDQklTQ2pvSWJHOWpZV3hmZGpJb0FBUAE/sections/CAQiUENCSVNOam9JYkc5allXeGZkakpDRUd4dlkyRnNYM1l5WDNObFkzUnBiMjV5Q3hJSkwyMHZNRGRxZW5wNGVnc0tDUzl0THpBM2FucDZlQ2dBKjEIACotCAoiJ0NCSVNGem9JYkc5allXeGZkako2Q3dvSkwyMHZNRGRxZW5wNEtBQVABUAE?hl=tr&gl=TR&ceid=TR%3Atr", "Ordu", "news.google.com", "google_news"),
        SourceConfig("Ordu Büyükşehir Belediyesi", "https://haber.ordu.bel.tr/", "Resmî Kurumlar", "ordu.bel.tr", "ordu_bel"),
        SourceConfig("TRT Haber Ordu", "https://www.trthaber.com/yerelhaberler/ordu/", "Ordu", "trthaber.com", "trt")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Android 15/targetSdk 35 edge-to-edge nedeniyle içerik sistem çubuklarının
        // altına girmesin; özellikle alt butonlar navigasyon çubuğunun altında kalmasın.
        val root = findViewById<View>(R.id.root)
        val initialTop = root.paddingTop
        val initialBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(
                top = initialTop + bars.top,
                bottom = initialBottom + bars.bottom
            )
            insets
        }
        ViewCompat.requestApplyInsets(root)

        status = findViewById(R.id.status)
        adapter = NewsAdapter(emptyList())
        findViewById<RecyclerView>(R.id.newsList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        buildCategories()
        findViewById<Button>(R.id.adminButton).setOnClickListener { showSourceInfo() }
        findViewById<Button>(R.id.facebookButton).setOnClickListener { openFacebookPage() }
        findViewById<Button>(R.id.refreshButton).setOnClickListener { loadNews() }

        loadNews()
    }

    private fun loadNews() {
        status.text = "● ${sources.size} KAYNAK TARANIYOR"
        status.alpha = 0.9f

        executor.execute {
            val jobs = sources.map { source ->
                executor.submit<List<News>> {
                    try {
                        fetchSource(source)
                    } catch (_: Exception) {
                        emptyList()
                    }
                }
            }
            val fetched = jobs.flatMap { job ->
                try { job.get() } catch (_: Exception) { emptyList() }
            }

            val unique = fetched
                .distinctBy { normalize(it.title) }
                .sortedByDescending { it.publishedAt.time }
                .take(60)

            runOnUiThread {
                allNews = unique
                adapter.submit(allNews)
                status.text = if (allNews.isEmpty()) "● HABER BULUNAMADI" else "● CANLI • ${allNews.size} HABER"
                findViewById<TextView>(R.id.pageTitle).text =
                    if (allNews.isEmpty()) "Haber alınamadı — Yenile'ye dokunun" else "Gölköy / Ordu Gündem"
            }
        }
    }

    private fun fetchSource(source: SourceConfig): List<News> {
        val doc = connect(source.url, source).get()
        val result = LinkedHashMap<String, News>()
        val candidates = LinkedHashMap<String, org.jsoup.nodes.Element>()

        for (a in doc.select("a[href], a[data-n-href], article a")) {
            val title = cleanText(a.text())
            val href = a.absUrl("href").ifBlank { a.absUrl("data-n-href") }
            if (!isCandidate(title, href, source)) continue
            if (title.length < 18 || title.length > 220) continue
            val key = normalize(title)
            if (key.isNotBlank()) candidates.putIfAbsent(key, a)
            if (candidates.size >= 40) break
        }

        for ((key, anchor) in candidates) {
            if (result.size >= 15) break
            val title = cleanText(anchor.text())
            val href = anchor.absUrl("href").ifBlank { anchor.absUrl("data-n-href") }
            if (href.isBlank()) continue

            // Önce liste kartındaki zamanı, yoksa haber detayındaki yayın zamanını dene.
            val publishedAt = extractPublishedDate(anchor)
                ?: fetchDetailPublishedDate(href, source)
                ?: continue
            if (!isRecent(publishedAt)) continue

            val parentText = anchor.parent()?.text()?.let(::cleanText).orEmpty()
            val summary = parentText
                .replace(title, "", ignoreCase = false)
                .trim()
                .takeIf { it.length >= 25 && it != title }
                ?: "Güncel haber. Haberin tamamını görüntülemek için dokunun."

            result[key] = News(
                category = classify(source.category, title),
                title = title,
                summary = summary.take(240),
                source = source.name,
                url = href,
                publishedAt = publishedAt
            )
        }
        val direct = result.values.toList()
        if (direct.isNotEmpty()) return direct

        // Site 403/robots/CDN nedeniyle doğrudan okunamazsa, aynı alan adının
        // son haberlerini Google News RSS üzerinden orijinal bağlantılarıyla almayı dene.
        return fetchViaGoogleNewsRss(source)
    }

    private fun fetchViaGoogleNewsRss(source: SourceConfig): List<News> {
        if (source.kind == "google_news") return emptyList()
        return try {
            val rssUrl = Uri.parse("https://news.google.com/rss/search")
                .buildUpon()
                .appendQueryParameter("q", "site:${source.host} Ordu")
                .appendQueryParameter("hl", "tr")
                .appendQueryParameter("gl", "TR")
                .appendQueryParameter("ceid", "TR:tr")
                .build().toString()
            val doc = connect(rssUrl, source).get()
            val out = mutableListOf<News>()
            for (item in doc.select("item")) {
                if (out.size >= 15) break
                val title = cleanText(item.selectFirst("title")?.text().orEmpty())
                val href = item.selectFirst("link")?.text()?.trim().orEmpty()
                val date = parseDate(item.selectFirst("pubDate")?.text().orEmpty()) ?: continue
                if (title.length < 12 || href.isBlank() || !isRecent(date)) continue
                out += News(
                    category = classify(source.category, title),
                    title = title,
                    summary = "Güncel haber. Haberin tamamını görüntülemek için dokunun.",
                    source = source.name,
                    url = href,
                    publishedAt = date
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun connect(url: String, source: SourceConfig): org.jsoup.Connection =
        Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/154.0 Mobile Safari/537.36 GolkoyHaber/2.0")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.7,en;q=0.5")
            .header("Cache-Control", "no-cache")
            .referrer("https://www.google.com/")
            .timeout(10_000)
            .maxBodySize(3 * 1024 * 1024)
            .followRedirects(true)
            .ignoreHttpErrors(true)
            .ignoreContentType(true)

    private fun fetchDetailPublishedDate(href: String, source: SourceConfig): Date? {
        return try {
            val doc = connect(href, source).get()
            val candidates = linkedSetOf<String>()
            doc.select("time[datetime]").forEach { candidates += it.attr("datetime") }
            doc.select("meta[property=article:published_time], meta[name=datePublished], meta[itemprop=datePublished]")
                .forEach { candidates += it.attr("content") }
            doc.select("script[type=application/ld+json]").forEach { script ->
                val raw = script.data()
                Regex("\\\"datePublished\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"")
                    .find(raw)?.groupValues?.getOrNull(1)?.let { candidates += it }
            }
            doc.select("[class*=date], [class*=time], [class*=tarih], [class*=yayin], [class*=publish], [class*=meta]").forEach { candidates += it.text() }
            candidates.asSequence().mapNotNull { parseDate(it) }.firstOrNull()
        } catch (_: Exception) {
            null
        }
    }

    private fun cleanText(value: String): String =
        value.replace(Regex("\\s+"), " ").trim()

    private fun extractPublishedDate(anchor: org.jsoup.nodes.Element): Date? {
        val candidates = linkedSetOf<String>()

        // Linkin kendisi ve yakın kapsayıcılar: mevcut kaynaklarda tarih çoğunlukla
        // başlığın yanında veya aynı kart/listede bulunuyor.
        candidates += anchor.text()
        anchor.parent()?.let { parent ->
            candidates += parent.text()
            parent.select("time[datetime]").forEach { candidates += it.attr("datetime") }
            parent.parent()?.let { grandParent ->
                candidates += grandParent.text()
                grandParent.select("time[datetime]").forEach { candidates += it.attr("datetime") }
            }
        }
        anchor.select("time[datetime]").forEach { candidates += it.attr("datetime") }
        anchor.parents().take(3).forEach { ancestor ->
            ancestor.select("time[datetime]").forEach { candidates += it.attr("datetime") }
        }

        for (text in candidates) {
            parseDate(text)?.let { return it }
        }
        return null
    }

    private fun parseDate(raw: String): Date? {
        val text = raw.replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null

        // Haberler.com gibi kaynakların göreli zamanları.
        val now = Calendar.getInstance()
        val lower = text.lowercase(Locale("tr", "TR"))
        Regex("\\b(\\d+)\\s*saat\\s*önce\\b").find(lower)?.let { m ->
            val hours = m.groupValues[1].toIntOrNull() ?: return@let
            return Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, -hours) }.time
        }
        Regex("\\b(\\d+)\\s*dakika\\s*önce\\b").find(lower)?.let { m ->
            val minutes = m.groupValues[1].toIntOrNull() ?: return@let
            return Calendar.getInstance().apply { add(Calendar.MINUTE, -minutes) }.time
        }
        if (Regex("\\bşimdi\\b|\\bşu an\\b").containsMatchIn(lower)) return now.time
        if (Regex("\\bbugün\\b").containsMatchIn(lower)) {
            Regex("bugün\\s+(\\d{1,2}):(\\d{2})").find(lower)?.let { m ->
                now.set(Calendar.HOUR_OF_DAY, m.groupValues[1].toInt())
                now.set(Calendar.MINUTE, m.groupValues[2].toInt())
                now.set(Calendar.SECOND, 0)
                now.set(Calendar.MILLISECOND, 0)
            }
            return now.time
        }
        if (Regex("\\bdün\\b").containsMatchIn(lower)) {
            val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
            Regex("dün\\s+(\\d{1,2}):(\\d{2})").find(lower)?.let { m ->
                yesterday.set(Calendar.HOUR_OF_DAY, m.groupValues[1].toInt())
                yesterday.set(Calendar.MINUTE, m.groupValues[2].toInt())
                yesterday.set(Calendar.SECOND, 0)
                yesterday.set(Calendar.MILLISECOND, 0)
            }
            return yesterday.time
        }

        val rssPatterns = listOf(
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm Z",
            "dd MMM yyyy HH:mm:ss Z"
        )
        for (pattern in rssPatterns) {
            try {
                val parser = SimpleDateFormat(pattern, Locale.ENGLISH)
                parser.isLenient = false
                return parser.parse(text)
            } catch (_: Exception) {
                // RSS tarih biçimi değilse normal Türkçe tarih biçimlerine geç.
            }
        }

        val patterns = listOf(
            "dd.MM.yyyy HH:mm", "dd.MM.yyyy",
            "dd/MM/yyyy HH:mm", "dd/MM/yyyy",
            "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
            "dd MMMM yyyy, HH:mm", "dd MMMM yyyy HH:mm", "dd MMMM yyyy",
            "yyyy MMMM dd, HH:mm", "yyyy MMMM dd HH:mm", "yyyy MMMM dd"
        )
        for (pattern in patterns) {
            try {
                val parser = SimpleDateFormat(pattern, Locale("tr", "TR"))
                parser.isLenient = false
                val regex = when {
                    pattern.startsWith("dd.MM") -> "\\b\\d{1,2}\\.\\d{1,2}\\.\\d{4}(?:\\s+\\d{1,2}:\\d{2})?"
                    pattern.startsWith("dd/MM") -> "\\b\\d{1,2}/\\d{1,2}/\\d{4}(?:\\s+\\d{1,2}:\\d{2})?"
                    pattern.startsWith("yyyy-MM-dd") -> "\\b\\d{4}-\\d{2}-\\d{2}(?:[T ]\\d{1,2}:\\d{2}(?::\\d{2})?(?:Z|[+-]\\d{2}:?\\d{2})?)?"
                    pattern.startsWith("yyyy MMMM") -> "\\b\\d{4}\\s+(?:Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık)\\s+\\d{1,2}(?:,?\\s+\\d{1,2}:\\d{2})?"
                    else -> "\\b\\d{1,2}\\s+(?:Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık)\\s+\\d{4}(?:,?\\s+\\d{1,2}:\\d{2})?"
                }
                val match = Regex(regex).find(text)?.value ?: continue
                return parser.parse(match)
            } catch (_: Exception) {
                // Diğer tarih biçimini dene.
            }
        }
        return null
    }

    private fun isRecent(date: Date): Boolean {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val yesterday = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val candidate = Calendar.getInstance().apply { time = date }

        // Takvim günü bazlı filtre: bugün + dün. Gelecek tarihli içerikleri de alma.
        return !candidate.before(yesterday) && candidate.before(tomorrow)
    }

    private fun isCandidate(title: String, href: String, source: SourceConfig): Boolean {
        if (href.isBlank()) return false
        val lower = href.lowercase()
        if (lower.startsWith("mailto:") || lower.startsWith("javascript:") || lower.startsWith("tel:")) return false
        if (title.equals("Anasayfa", true) || title.equals("Tümü", true)) return false

        if (source.kind == "google_news") {
            return lower.contains("news.google.com/") || lower.contains("http")
        }
        if (!lower.contains(source.host)) return false

        val pathHint = listOf("haber", "icerik", "duyuru", "ilan", "basin", "etkinlik", "proje", "gundem", "yerel")
        return pathHint.any { lower.contains(it) } ||
            title.contains("haber", true) || title.contains("duyuru", true) ||
            title.contains("mesaj", true) || title.contains("ordu", true)
    }

    private fun classify(baseCategory: String, title: String): String {
        if (baseCategory != "Resmî Kurumlar") return baseCategory
        val t = title.lowercase()
        return when {
            listOf("emniyet", "jandarma", "asayiş", "güvenlik", "trafik", "kaza", "operasyon").any { t.contains(it) } -> "Asayiş"
            listOf("sağlık", "hastane", "112", "doktor", "hasta").any { t.contains(it) } -> "Sağlık"
            listOf("meteoroloji", "yağış", "fırtına", "sel", "sıcaklık", "hava").any { t.contains(it) } -> "Hava"
            listOf("tarım", "fındık", "üretici", "çiftçi", "kokarca").any { t.contains(it) } -> "Tarım"
            listOf("spor", "şampiyon", "güreş", "futbol").any { t.contains(it) } -> "Spor"
            listOf("eğitim", "okul", "öğrenci", "öğretmen").any { t.contains(it) } -> "Eğitim"
            else -> "Resmî Kurumlar"
        }
    }

    private fun normalize(value: String): String =
        value.lowercase()
            .replace("ğ", "g").replace("ü", "u").replace("ş", "s")
            .replace("ı", "i").replace("ö", "o").replace("ç", "c")
            .replace(Regex("[^a-z0-9 ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun buildCategories() {
        val bar = findViewById<LinearLayout>(R.id.categoryBar)
        val categories = listOf("Tümü", "Gölköy", "Resmî", "Asayiş", "Eğitim", "Sağlık", "Spor", "Tarım", "Siyaset", "Hava", "Vefat")
        categories.forEach { category ->
            val button = MaterialButton(this).apply {
                text = category
                isAllCaps = false
                minHeight = 48
                minimumHeight = 48
                setOnClickListener {
                    val filtered = when (category) {
                        "Tümü" -> allNews
                        "Gölköy" -> allNews.filter { it.category == "Gölköy" }
                        "Resmî" -> allNews.filter { it.category == "Resmî Kurumlar" }
                        else -> allNews.filter { it.category.contains(category, ignoreCase = true) }
                    }
                    adapter.submit(filtered)
                    findViewById<TextView>(R.id.pageTitle).text =
                        if (category == "Tümü") "Gölköy / Ordu Gündem" else category
                }
            }
            bar.addView(button)
        }
    }

    private fun showSourceInfo() {
        AlertDialog.Builder(this)
            .setTitle("GölköyHaber kaynak merkezi")
            .setMessage(
                "Canlı kaynaklar (${sources.size}):\n\n" +
                    sources.joinToString("\n") { "• ${it.name}" } +
                    "\n\nHaberler uygulama açılışında internetten çekilir.\n" +
                    "Aynı başlığa sahip içerikler tekilleştirilir.\n" +
                    "Sadece bugün ve dünden yayımlanan, tarihi tespit edilebilen içerikler gösterilir.\n\n" +
                    "Facebook düğmesi sayfayı açar. Tek haber paylaşımı için haber kartındaki Facebook paylaş düğmesi kullanılabilir. Sayfaya otomatik yayın için güvenli bir sunucu + Meta Page Access Token gerekir."
            )
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun openFacebookPage() {
        safeOpenUrl("https://www.facebook.com/habergolkoy52")
    }

    fun shareNewsToFacebook(news: News) {
        // facebook.com/sharer/sharer.php bazı cihazlarda uygun Activity bulunamadığında
        // ActivityNotFoundException üretebiliyor. Android'in standart paylaşım akışını
        // kullanarak uygulamanın kapanmasını engelliyoruz. Kullanıcı listeden Facebook'u seçer.
        val shareText = "GölköyHaber: ${news.title}\n\n${news.url}"
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, news.title)
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(intent, "Haber paylaş"))
        } catch (_: Exception) {
            safeOpenUrl(news.url)
        }
    }

    private fun safeOpenUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                android.widget.Toast.makeText(this, "Bu bağlantıyı açacak uygulama bulunamadı.", android.widget.Toast.LENGTH_SHORT).show()
            }
        } catch (_: Exception) {
            android.widget.Toast.makeText(this, "Bağlantı açılamadı.", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    fun openNewsUrl(url: String) {
        safeOpenUrl(url)
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}

private class NewsAdapter(private var items: List<News>) : RecyclerView.Adapter<NewsViewHolder>() {
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): NewsViewHolder {
        val view = android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent, false)
        return NewsViewHolder(view)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size
    fun submit(newItems: List<News>) { items = newItems; notifyDataSetChanged() }
}

private class NewsViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
    fun bind(news: News) {
        itemView.findViewById<TextView>(R.id.category).text = news.category.uppercase()
        itemView.findViewById<TextView>(R.id.title).text = news.title
        itemView.findViewById<TextView>(R.id.summary).text = news.summary
        itemView.findViewById<TextView>(R.id.source).text = "Kaynak: ${news.source}"
        itemView.findViewById<android.widget.Button>(R.id.shareFacebookButton).setOnClickListener {
            (itemView.context as? MainActivity)?.shareNewsToFacebook(news)
        }
        itemView.setOnClickListener {
            (itemView.context as? MainActivity)?.openNewsUrl(news.url)
        }
    }
}
