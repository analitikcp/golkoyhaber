# GölköyHaber 2.1

Gölköy ve Ordu için güncel haber akışı.

## Kaynaklar

Uygulamada **14 bağımsız kaynak tanımı** bulunur:

1. Ordu Valiliği
2. Gölköy Kaymakamlığı
3. Gölköy Belediyesi
4. Gölköy İlçe Millî Eğitim
5. İHA Ordu
6. Haberler.com Ordu
7. DHA Ordu
8. Habertürk Yerel Ordu
9. SonDakika.com Ordu
10. NTV Ordu
11. CNN Türk Ordu
12. Google News Ordu
13. Ordu Büyükşehir Belediyesi
14. TRT Haber Ordu

Kaynaklar paralel taranır. Her kaynakta önce kendi sayfası denenir; ardından aynı kaynak için **site ile sınırlandırılmış Google News RSS** yedeği kullanılır.

## Veri doğrulama ve tarih

- Yalnızca **bugün ve dün** yayımlanan içerikler gösterilir.
- Gelecek tarihli içerikler kabul edilmez.
- Tarihi doğrulanamayan doğrudan sayfa içerikleri atılır.
- `Bugün`, `Dün`, `X saat önce`, `X dakika önce`, Türkçe ay adları, ISO ve RSS tarih biçimleri desteklenir.
- Doğrudan sayfada tarih başlıkla aynı HTML düğümünde değilse parser altı üst düğüme kadar tarih alanlarını tarar.
- Aynı haber başlığı kaynaklar arasında tekrar gösterilmez.

## Kaynak çekme mimarisi

Her kaynak için:

1. HTTPS doğrudan sayfa isteği.
2. HTTP durum kodu kontrolü.
3. Linklerin alan adı doğrulaması.
4. Yakın HTML düğümlerinden yayın tarihi çıkarımı.
5. Son 2 gün filtresi.
6. Site ile sınırlandırılmış Google News RSS fallback'i.
7. Başlık/URL üzerinden tekilleştirme.

Google News sonucu içinde kaynak alan adı mevcutsa ayrıca alan adı eşleştirmesi yapılır. Alan adı Google tarafından gönderilmezse, sorgunun `site:` kısıtı korunarak sonuç kabul edilir.

## Derleme

GitHub Actions Java 17 + Gradle 8.10.2 ile `:app:assembleDebug` çalıştırır.

ZIP'te Gradle wrapper yerine CI'nin sabit Gradle 8.10.2 kurulumu kullanılır. CI, derlemeden önce `scripts/verify_project.py` ile kaynak ve yapı bütünlüğünü kontrol eder.

## Önemli düzeltmeler

- `shareNewsToFacebook()` ve `openNewsUrl()` artık top-level `NewsViewHolder` tarafından erişilebilecek `internal` metotlardır. Önceki sürümde `private` olmaları Kotlin derleme hatasına yol açıyordu.
- Kaynak sayımı artık kırılgan `grep` ifadelerine bağlı değildir.
- İki farklı workflow dosyasındaki çelişkili kaynak kontrolleri kaldırıldı.
- `ignoreHttpErrors(true)` kaldırıldı; HTTP hata durumları açıkça ele alınıyor.
- Doğrudan tarama ile RSS fallback birbirinden ayrıldı.
- Her kaynak için Future timeout eklendi.
- Tarih çıkarımı daha geniş HTML çevresinde yapılıyor.
- Vefat kategorisi için eksik sınıflandırma düzeltildi.
- URL açma işleminde yalnızca `http/https` şemaları kabul ediliyor.
- Kaynak durum ekranı gerçek tarama sonucunu gösteriyor.


## 2.1.1 link opening fix
- News card links now launch `ACTION_VIEW` directly instead of relying on `resolveActivity()`, which can incorrectly return null on Android 11+ because of package-visibility rules.
- Added HTTP/HTTPS browser intent visibility declarations to `AndroidManifest.xml`.
- Added a chooser fallback and clearer error handling when a device genuinely has no browser.


## 2.1.3 hotfix
- Haber kartı, başlık, özet ve kaynak satırına dokunmak doğrudan uygulama içi haber görüntüleyicisini açar.
- Tarayıcı paket görünürlüğüne bağlı `resolveActivity`/browser kontrolü kullanılmaz.
- Google News dahil HTTPS bağlantıları önce WebView ile açılır; WebView başlatılamazsa sistem tarayıcısına düşer.
- Kategori alanı GridLayout yerine iki gerçek yatay satır olarak oluşturulur; 5+5 butonun dokunma alanları birbirine girmez.
- Kaynaklar butonu yeniden tarama başlatmak yerine son tamamlanan taramanın sonuçlarını anında gösterir.
- Sürüm: 2.1.3 (versionCode 8).
