package com.golkoyhaber.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

data class News(
    val category: String,
    val title: String,
    val summary: String,
    val source: String,
    val url: String,
    val publishedAt: Date
)

private data class SourceConfig(
    val name: String,
    val url: String,
    val category: String,
    val host: String,
    val kind: String = "generic",
    val googleQuery: String = "Ordu"
)

private data class SourceResult(
    val source: SourceConfig,
    val news: List<News>,
    val error: String? = null
)

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: NewsAdapter
    private lateinit var status: TextView
    private lateinit var pageTitle: TextView
    private lateinit var sourceStatus: TextView
    private val executor = Executors.newFixedThreadPool(12)
    private var allNews: List<News> = emptyList()
    private var isLoading = false

    // 14 independent source definitions. Direct page parsing is attempted first;
    // Google News RSS is a fallback, not the primary source of truth.
    private val sources = listOf(
        SourceConfig("Ordu Valiliği", "https://www.ordu.gov.tr/", "Resmî Kurumlar", "ordu.gov.tr", googleQuery = "site:ordu.gov.tr Ordu"),
        SourceConfig("Gölköy Kaymakamlığı", "https://www.golkoy.gov.tr/haberler", "Gölköy", "golkoy.gov.tr", googleQuery = "site:golkoy.gov.tr Gölköy"),
        SourceConfig("Gölköy Belediyesi", "https://www.golkoy.bel.tr/", "Gölköy", "golkoy.bel.tr", googleQuery = "site:golkoy.bel.tr Gölköy"),
        SourceConfig("Gölköy İlçe Millî Eğitim", "https://golkoy.meb.gov.tr/", "Eğitim", "golkoy.meb.gov.tr", googleQuery = "site:golkoy.meb.gov.tr Gölköy"),
        SourceConfig("İHA Ordu", "https://www.iha.com.tr/ordu", "Ordu", "iha.com.tr", "iha", "site:iha.com.tr/ordu Ordu"),
        SourceConfig("Haberler.com Ordu", "https://www.haberler.com/ordu/", "Ordu", "haberler.com", "haberler", "site:haberler.com/ordu Ordu"),
        SourceConfig("DHA Ordu", "https://www.dha.com.tr/ordu-haber/", "Ordu", "dha.com.tr", "dha", "site:dha.com.tr/yerel-haberler/ordu Ordu"),
        SourceConfig("Habertürk Yerel Ordu", "https://yerel-haberler.haberturk.com/ordu-haberleri", "Ordu", "haberturk.com", "haberturk", "site:haberturk.com Ordu"),
        SourceConfig("SonDakika.com Ordu", "https://www.sondakika.com/ordu/", "Ordu", "sondakika.com", "sondakika", "site:sondakika.com/ordu Ordu"),
        SourceConfig("NTV Ordu", "https://www.ntv.com.tr/haberleri/ordu", "Ordu", "ntv.com.tr", "ntv", "site:ntv.com.tr Ordu"),
        SourceConfig("CNN Türk Ordu", "https://www.cnnturk.com/ordu-haber/", "Ordu", "cnnturk.com", "cnnturk", "site:cnnturk.com Ordu"),
        SourceConfig("Google News Ordu", "https://news.google.com/", "Ordu", "news.google.com", "google_news", "Ordu Gölköy"),
        SourceConfig("Ordu Büyükşehir Belediyesi", "https://haber.ordu.bel.tr/", "Resmî Kurumlar", "ordu.bel.tr", "ordu_bel", "site:ordu.bel.tr Ordu"),
        SourceConfig("TRT Haber Ordu", "https://www.trthaber.com/yerelhaberler/ordu/", "Ordu", "trthaber.com", "trt", "site:trthaber.com Ordu")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        val initialTop = root.paddingTop
        val initialBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = initialTop + bars.top, bottom = initialBottom + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        status = findViewById(R.id.status)
        pageTitle = findViewById(R.id.pageTitle)
        sourceStatus = findViewById(R.id.sourceStatus)

        adapter = NewsAdapter(emptyList())
        findViewById<RecyclerView>(R.id.newsList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            setHasFixedSize(false)
        }

        buildCategories()
        findViewById<Button>(R.id.refreshButton).setOnClickListener { loadNews() }
        findViewById<Button>(R.id.adminButton).setOnClickListener { showSourceInfo() }
        findViewById<Button>(R.id.facebookButton).setOnClickListener { openFacebookPage() }

        loadNews()
    }

    private fun loadNews() {
        if (isLoading) return
        isLoading = true
        status.text = "● ${sources.size} KAYNAK TARANIYOR"
        pageTitle.text = "Güncel Ordu / Gölköy Haberleri"
        sourceStatus.text = "Bugün + dün • Doğrudan + RSS yedekleri"

        executor.execute {
            val jobs = sources.map { source ->
                executor.submit<SourceResult> { fetchSource(source) }
            }

            val results = jobs.mapIndexed { index, job ->
                try {
                    job.get(35, TimeUnit.SECONDS)
                } catch (e: Exception) {
                    job.cancel(true)
                    SourceResult(sources[index], emptyList(), e.javaClass.simpleName)
                }
            }

            val fetched = results.flatMap { it.news }
                .filter { isRecent(it.publishedAt) }
                .distinctBy { canonicalArticleKey(it) }
                .sortedByDescending { it.publishedAt.time }
                .take(60)

            val okSources = results.count { it.news.isNotEmpty() }
            val totalFetched = results.sumOf { it.news.size }

            runOnUiThread {
                isLoading = false
                allNews = fetched
                adapter.submit(allNews)
                status.text = if (allNews.isEmpty()) "● HABER BULUNAMADI" else "● CANLI • ${allNews.size} HABER"
                sourceStatus.text =
                    "$okSources/${sources.size} kaynak veri verdi • $totalFetched içerik bulundu • sadece bugün + dün"
                pageTitle.text = if (allNews.isEmpty()) "Haber bulunamadı" else "Gölköy / Ordu Gündem"
            }
        }
    }

    private fun fetchSource(source: SourceConfig): SourceResult {
        val direct = try { fetchDirect(source) } catch (e: Exception) { emptyList() }
        val directRecent = direct.filter { isRecent(it.publishedAt) }

        // If direct parsing produced useful results, still merge RSS because the
        // listing page may contain only a subset of the newest stories.
        val rss = try { fetchViaGoogleNewsRss(source) } catch (_: Exception) { emptyList() }

        val merged = (directRecent + rss)
            .filter { isRecent(it.publishedAt) }
            .filter { it.title.length >= 12 && it.url.isNotBlank() }
            .distinctBy { canonicalArticleKey(it) }
            .sortedByDescending { it.publishedAt.time }
            .take(15)

        return if (merged.isNotEmpty()) {
            SourceResult(source, merged)
        } else {
            SourceResult(source, emptyList(), "no_recent_items")
        }
    }

    private fun fetchDirect(source: SourceConfig): List<News> {
        if (source.kind == "google_news") return emptyList()

        val connection = connect(source.url)
        val response = connection.execute()
        if (response.statusCode() !in 200..399) {
            throw IllegalStateException("HTTP ${response.statusCode()}")
        }

        val doc = response.parse()
        val candidates = LinkedHashMap<String, Element>()

        // Look at anchors and article links. We do not require a date to be on
        // the same node: extractPublishedDate walks several surrounding levels.
        for (a in doc.select("a[href], a[data-n-href], article a")) {
            val title = cleanText(a.text())
            val href = a.absUrl("href").ifBlank { a.absUrl("data-n-href") }
            if (!isCandidate(title, href, source)) continue
            if (title.length !in 12..240) continue

            val key = normalize(title)
            candidates.putIfAbsent(key, a)
            if (candidates.size >= 45) break
        }

        val out = mutableListOf<News>()
        for ((_, anchor) in candidates) {
            if (out.size >= 20) break
            val title = cleanText(anchor.text())
            val href = anchor.absUrl("href").ifBlank { anchor.absUrl("data-n-href") }
            val published = extractPublishedDate(anchor) ?: continue
            if (!isRecent(published)) continue

            val summary = surroundingText(anchor, title)
                .takeIf { it.length >= 25 }
                ?: "Güncel haber. Haberin tamamını görüntülemek için dokunun."

            out += News(
                classify(source.category, title),
                title,
                summary.take(240),
                source.name,
                href,
                published
            )
        }
        return out
    }

    private fun fetchViaGoogleNewsRss(source: SourceConfig): List<News> {
        val query = source.googleQuery
        val rssUrl = Uri.parse("https://news.google.com/rss/search")
            .buildUpon()
            .appendQueryParameter("q", "$query when:2d")
            .appendQueryParameter("hl", "tr")
            .appendQueryParameter("gl", "TR")
            .appendQueryParameter("ceid", "TR:tr")
            .build()
            .toString()

        val response = connect(rssUrl).execute()
        if (response.statusCode() !in 200..399) {
            throw IllegalStateException("RSS HTTP ${response.statusCode()}")
        }

        val doc = response.parse()
        val out = mutableListOf<News>()

        for (item in doc.select("item")) {
            if (out.size >= 20) break

            val rawTitle = cleanText(item.selectFirst("title")?.text().orEmpty())
            val href = cleanText(item.selectFirst("link")?.text().orEmpty())
            val date = parseDate(item.selectFirst("pubDate")?.text().orEmpty()) ?: continue
            val sourceElement = item.selectFirst("source")
            val originalHost = normalizeHost(sourceElement?.attr("url").orEmpty())

            // For a site-restricted query, a missing <source url> is tolerated
            // because Google sometimes omits that attribute. If it is present,
            // it must match the configured source.
            if (source.kind != "google_news" &&
                originalHost.isNotBlank() &&
                !hostMatches(originalHost, source.host)
            ) continue

            if (rawTitle.length < 12 || href.isBlank() || !isRecent(date)) continue

            val displayTitle = rawTitle.substringBefore(" - ").trim().ifBlank { rawTitle }
            if (displayTitle.length < 12) continue

            out += News(
                classify(source.category, displayTitle),
                displayTitle,
                "Güncel haber. Haberin tamamını görüntülemek için dokunun.",
                source.name,
                href,
                date
            )
        }
        return out
    }

    private fun connect(url: String): org.jsoup.Connection =
        Jsoup.connect(url)
            .userAgent(
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/154.0 Mobile Safari/537.36 GolkoyHaber/2.1"
            )
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.6")
            .header("Cache-Control", "no-cache")
            .header("Pragma", "no-cache")
            .timeout(12_000)
            .followRedirects(true)
            .ignoreHttpErrors(false)
            .ignoreContentType(true)

    private fun extractPublishedDate(anchor: Element): Date? {
        val values = LinkedHashSet<String>()

        fun collect(element: Element) {
            values += element.attr("datetime")
            values += element.attr("content")
            values += element.attr("data-date")
            values += element.attr("data-datetime")
            values += element.text()
            element.select("time, [datetime], [class*=date], [class*=time], [class*=tarih], [class*=yayin], [class*=publish], meta[property=article:published_time], meta[name=date]").forEach {
                values += it.attr("datetime")
                values += it.attr("content")
                values += it.attr("data-date")
                values += it.text()
            }
        }

        var current: Element? = anchor
        repeat(6) {
            current?.let(::collect)
            current = current?.parent()
        }

        // Prefer explicit machine-readable timestamps when several candidates
        // exist; otherwise fall back to visible relative/date text.
        return values.asSequence()
            .mapNotNull(::parseDate)
            .firstOrNull { !it.after(Date(System.currentTimeMillis() + 5 * 60_000L)) }
    }

    private fun surroundingText(anchor: Element, title: String): String {
        var current: Element? = anchor.parent()
        repeat(4) {
            val text = current?.text()?.let(::cleanText).orEmpty()
                .replace(title, "")
                .trim()
            if (text.length in 25..500) return text
            current = current?.parent()
        }
        return ""
    }

    private fun parseDate(raw: String): Date? {
        val text = cleanText(raw)
        if (text.isBlank()) return null

        Regex("(?i)\\b(\\d+)\\s*(dakika|dk)\\s*önce\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.MINUTE, -it.groupValues[1].toInt())
            }.time
        }
        Regex("(?i)\\b(\\d+)\\s*(saat)\\s*önce\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.HOUR_OF_DAY, -it.groupValues[1].toInt())
            }.time
        }
        Regex("(?i)\\b(\\d+)\\s*(gün)\\s*önce\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -it.groupValues[1].toInt())
            }.time
        }

        Regex("(?i)\\bbugün(?:\\s+(\\d{1,2}):(\\d{2}))?\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                it.groupValues.getOrNull(1)?.takeIf(String::isNotBlank)?.let { h -> set(Calendar.HOUR_OF_DAY, h.toInt()) }
                it.groupValues.getOrNull(2)?.takeIf(String::isNotBlank)?.let { m -> set(Calendar.MINUTE, m.toInt()) }
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.time
        }

        Regex("(?i)\\bdün(?:\\s+(\\d{1,2}):(\\d{2}))?\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -1)
                it.groupValues.getOrNull(1)?.takeIf(String::isNotBlank)?.let { h -> set(Calendar.HOUR_OF_DAY, h.toInt()) }
                it.groupValues.getOrNull(2)?.takeIf(String::isNotBlank)?.let { m -> set(Calendar.MINUTE, m.toInt()) }
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.time
        }

        val rssPatterns = listOf(
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm Z",
            "dd MMM yyyy HH:mm:ss Z",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
        )
        for (pattern in rssPatterns) {
            try {
                SimpleDateFormat(pattern, Locale.ENGLISH).apply { isLenient = false }
                    .parse(text)?.let { return it }
            } catch (_: Exception) {
            }
        }

        val trMonths = "Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık"
        val patterns = listOf(
            Regex("\\b\\d{1,2}\\.\\d{1,2}\\.\\d{4}(?:\\s+\\d{1,2}:\\d{2}(?::\\d{2})?)?"),
            Regex("\\b\\d{1,2}/\\d{1,2}/\\d{4}(?:\\s+\\d{1,2}:\\d{2}(?::\\d{2})?)?"),
            Regex("\\b\\d{4}-\\d{2}-\\d{2}(?:[T ]\\d{1,2}:\\d{2}(?::\\d{2})?(?:Z|[+-]\\d{2}:?\\d{2})?)?"),
            Regex("\\b\\d{1,2}\\s+(?:$trMonths)\\s+\\d{4}(?:,?\\s+\\d{1,2}:\\d{2})?", RegexOption.IGNORE_CASE),
            Regex("\\b\\d{4}\\s+(?:$trMonths)\\s+\\d{1,2}(?:,?\\s+\\d{1,2}:\\d{2})?", RegexOption.IGNORE_CASE)
        )
        val formats = listOf(
            "dd.MM.yyyy HH:mm:ss", "dd.MM.yyyy HH:mm", "dd.MM.yyyy",
            "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy HH:mm", "dd/MM/yyyy",
            "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
            "dd MMMM yyyy, HH:mm", "dd MMMM yyyy HH:mm", "dd MMMM yyyy",
            "yyyy MMMM dd, HH:mm", "yyyy MMMM dd HH:mm", "yyyy MMMM dd"
        )

        for (regex in patterns) {
            val match = regex.find(text)?.value ?: continue
            for (format in formats) {
                try {
                    SimpleDateFormat(format, Locale("tr", "TR")).apply { isLenient = false }
                        .parse(match)?.let { return it }
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    private fun isRecent(date: Date): Boolean {
        val now = Calendar.getInstance()
        val today = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val yesterday = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val c = Calendar.getInstance().apply { time = date }
        return !c.before(yesterday) && c.before(tomorrow)
    }

    private fun isCandidate(title: String, href: String, source: SourceConfig): Boolean {
        if (href.isBlank() || title.isBlank()) return false
        val lower = href.lowercase(Locale.ROOT)
        if (lower.startsWith("mailto:") || lower.startsWith("javascript:") || lower.startsWith("tel:")) return false
        if (!hostMatches(normalizeHost(href), source.host)) return false

        val titleLower = title.lowercase(Locale("tr", "TR"))
        val hints = listOf(
            "haber", "gündem", "gundem", "yerel", "ordu", "gölköy", "golkoy",
            "duyuru", "basın", "basin", "etkinlik", "proje", "vafat", "vefat"
        )
        return hints.any { lower.contains(it) || titleLower.contains(it) }
    }

    private fun hostMatches(actual: String, expected: String): Boolean {
        val a = normalizeHost(actual)
        val e = normalizeHost(expected)
        return a == e || a.endsWith(".$e") || e.endsWith(".$a")
    }

    private fun normalizeHost(value: String): String = try {
        val candidate = if (value.contains("://")) value else "https://$value"
        Uri.parse(candidate).host.orEmpty().removePrefix("www.").lowercase(Locale.ROOT)
    } catch (_: Exception) {
        value.substringAfter("://").substringBefore('/').removePrefix("www.").lowercase(Locale.ROOT)
    }

    private fun classify(base: String, title: String): String {
        val t = title.lowercase(Locale("tr", "TR"))
        if (t.contains("vefat") || t.contains("hayatını kaybetti") || t.contains("hayatini kaybetti") || t.contains("cenaze")) return "Vefat"

        if (base != "Resmî Kurumlar") return base
        return when {
            listOf("emniyet", "jandarma", "asayiş", "asayis", "güvenlik", "trafik", "kaza", "operasyon").any(t::contains) -> "Asayiş"
            listOf("sağlık", "saglik", "hastane", "112", "doktor", "hasta").any(t::contains) -> "Sağlık"
            listOf("meteoroloji", "yağış", "yagis", "fırtına", "firtina", "sel", "sıcaklık", "sicaklik", "hava").any(t::contains) -> "Hava"
            listOf("tarım", "tarim", "fındık", "findik", "üretici", "uretici", "çiftçi", "ciftci", "kokarca").any(t::contains) -> "Tarım"
            listOf("spor", "şampiyon", "sampiyon", "güreş", "gures", "futbol").any(t::contains) -> "Spor"
            listOf("eğitim", "egitim", "okul", "öğrenci", "ogrenci", "öğretmen", "ogretmen").any(t::contains) -> "Eğitim"
            else -> "Resmî Kurumlar"
        }
    }

    private fun canonicalArticleKey(news: News): String {
        val titleKey = normalize(news.title)
        val urlKey = normalizeUrl(news.url)
        return if (titleKey.isNotBlank()) titleKey else urlKey
    }

    private fun normalizeUrl(value: String): String = try {
        Uri.parse(value).buildUpon().clearQuery().fragment(null).build().toString().lowercase(Locale.ROOT)
    } catch (_: Exception) {
        value.trim().lowercase(Locale.ROOT)
    }

    private fun normalize(value: String): String = value.lowercase(Locale("tr", "TR"))
        .replace("ğ", "g").replace("ü", "u").replace("ş", "s").replace("ı", "i").replace("ö", "o").replace("ç", "c")
        .replace(Regex("[^a-z0-9 ]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun cleanText(value: String): String = value.replace(Regex("\\s+"), " ").trim()

    private fun buildCategories() {
        val bar = findViewById<GridLayout>(R.id.categoryBar)
        val categories = listOf("Tümü", "Gölköy", "Resmî", "Asayiş", "Eğitim", "Sağlık", "Spor", "Tarım", "Hava", "Vefat")
        categories.forEach { category ->
            val button = MaterialButton(this).apply {
                text = category
                isAllCaps = false
                minHeight = 40
                minimumHeight = 40
                setTextSize(12f)
                setPadding(2, 0, 2, 0)
                setOnClickListener {
                    val filtered = when (category) {
                        "Tümü" -> allNews
                        "Gölköy" -> allNews.filter { it.category == "Gölköy" }
                        "Resmî" -> allNews.filter { it.category == "Resmî Kurumlar" }
                        else -> allNews.filter { it.category.contains(category, true) }
                    }
                    adapter.submit(filtered)
                    pageTitle.text = if (category == "Tümü") "Gölköy / Ordu Gündem" else "$category Haberleri"
                }
            }
            val params = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                height = 42
                setMargins(2, 2, 2, 2)
            }
            bar.addView(button, params)
        }
    }

    private fun showSourceInfo() {
        AlertDialog.Builder(this)
            .setTitle("Kaynak Durumu")
            .setMessage("14 kaynak kontrol ediliyor…")
            .setPositiveButton("Kapat", null)
            .show()

        executor.execute {
            val jobs: List<Future<SourceResult>> = sources.map { source ->
                executor.submit<SourceResult> { fetchSource(source) }
            }
            val results = jobs.mapIndexed { index, job ->
                try { job.get(35, TimeUnit.SECONDS) }
                catch (e: Exception) {
                    job.cancel(true)
                    SourceResult(sources[index], emptyList(), e.javaClass.simpleName)
                }
            }

            runOnUiThread {
                val lines = results.map { result ->
                    val count = result.news.size
                    val suffix = if (count > 0) "$count güncel içerik" else "veri yok"
                    "• ${result.source.name}: $suffix"
                }
                AlertDialog.Builder(this)
                    .setTitle("Kaynak Durumu — bugün + dün")
                    .setMessage(
                        lines.joinToString("\n") +
                            "\n\nDoğrudan sayfa ve Google News RSS yedeği kullanılır." +
                            "\nTarihi doğrulanamayan veya 2 günden eski içerikler gösterilmez."
                    )
                    .setPositiveButton("Kapat", null)
                    .show()
            }
        }
    }

    private fun openFacebookPage() = safeOpenUrl("https://www.facebook.com/habergolkoy52")

    internal fun shareNewsToFacebook(news: News) {
        val shareText = "GölköyHaber | ${news.title}\n\n${news.url}"
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, news.title)
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(send, "Haberi paylaş"))
        } catch (_: Exception) {
            Toast.makeText(this, "Paylaşım menüsü açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    internal fun openNewsUrl(url: String) = safeOpenUrl(url)

    private fun safeOpenUrl(url: String) {
        val cleaned = url.trim()
        if (cleaned.isBlank()) {
            Toast.makeText(this, "Haber bağlantısı bulunamadı.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val parsed = Uri.parse(cleaned)
            val scheme = parsed.scheme?.lowercase(Locale.ROOT)
            val host = parsed.host?.lowercase(Locale.ROOT).orEmpty()
            if (scheme !in setOf("http", "https") || host.isBlank()) {
                Toast.makeText(this, "Geçersiz haber bağlantısı.", Toast.LENGTH_SHORT).show()
                return
            }

            // Do NOT gate ACTION_VIEW with resolveActivity(). On Android 11+
            // package-visibility rules can make resolveActivity() return null
            // even though a browser is actually capable of opening the URL.
            // Let Android resolve the intent and handle ActivityNotFoundException.
            startActivity(Intent(Intent.ACTION_VIEW, parsed).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: android.content.ActivityNotFoundException) {
            // A chooser is a useful second chance when multiple browsers/apps
            // exist but the default resolver cannot select one automatically.
            try {
                val parsed = Uri.parse(cleaned)
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_VIEW, parsed).apply {
                        addCategory(Intent.CATEGORY_BROWSABLE)
                    },
                    "Haberi aç"
                ))
            } catch (_: Exception) {
                Toast.makeText(this, "Bu cihazda web bağlantısını açacak uygulama bulunamadı.", Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Haber bağlantısı açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}

private class NewsAdapter(private var items: List<News>) : RecyclerView.Adapter<NewsViewHolder>() {
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): NewsViewHolder =
        NewsViewHolder(
            android.view.LayoutInflater.from(parent.context)
                .inflate(R.layout.item_news, parent, false)
        )

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size

    fun submit(newItems: List<News>) {
        items = newItems
        notifyDataSetChanged()
    }
}

private class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    fun bind(news: News) {
        itemView.findViewById<TextView>(R.id.category).text =
            news.category.uppercase(Locale("tr", "TR"))
        itemView.findViewById<TextView>(R.id.title).text = news.title
        itemView.findViewById<TextView>(R.id.summary).text = news.summary
        itemView.findViewById<TextView>(R.id.source).text =
            "${news.source} • ${formatTime(news.publishedAt)}"
        itemView.findViewById<Button>(R.id.shareFacebookButton)
            .setOnClickListener { (itemView.context as? MainActivity)?.shareNewsToFacebook(news) }
        itemView.setOnClickListener {
            (itemView.context as? MainActivity)?.openNewsUrl(news.url)
        }
    }

    private fun formatTime(date: Date): String =
        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(date)
}
