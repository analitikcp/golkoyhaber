package com.golkoyhaber.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class NewsWebViewActivity : Activity() {
    companion object {
        const val EXTRA_URL = "extra_url"
    }

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/154.0 Mobile Safari/537.36 GolkoyHaber/2.1.5"
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme?.lowercase()
                    if (scheme == "http" || scheme == "https") return false
                    return try {
                        startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, request.url))
                        true
                    } catch (_: Exception) {
                        true
                    }
                }

                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) {
                        Toast.makeText(this@NewsWebViewActivity, "Haber sayfası yüklenemedi.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            webChromeClient = WebChromeClient()
        }
        setContentView(webView)

        val url = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        if (url.isBlank()) {
            Toast.makeText(this, "Haber bağlantısı bulunamadı.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val parsed = android.net.Uri.parse(url)
        val scheme = parsed.scheme?.lowercase()
        if (scheme !in setOf("http", "https") || parsed.host.isNullOrBlank()) {
            Toast.makeText(this, "Geçersiz haber bağlantısı.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        webView.loadUrl(parsed.toString())
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
