#!/usr/bin/env python3
"""Fast CI checks for the GolkoyHaber Android project."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/golkoyhaber/app/MainActivity.kt"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
GRADLE = ROOT / "app/build.gradle.kts"

def fail(msg: str) -> None:
    raise SystemExit(f"VERIFY FAILED: {msg}")

for path in (MAIN, MANIFEST, GRADLE):
    if not path.is_file():
        fail(f"missing {path.relative_to(ROOT)}")

text = MAIN.read_text(encoding="utf-8")
if not text.startswith("package com.golkoyhaber.app"):
    fail("MainActivity package declaration is wrong")

sources = re.findall(r'SourceConfig\("([^"]+)"\s*,\s*"https://', text)
if len(sources) != 14:
    fail(f"expected 14 SourceConfig entries, found {len(sources)}")
if len(set(sources)) != len(sources):
    fail("duplicate source name")

for required in (
    "internal fun shareNewsToFacebook(news: News)",
    "internal fun openNewsUrl(url: String)",
    "fetchViaGoogleNewsRss(source)",
    "extractPublishedDate(anchor)",
    "job.get(35, TimeUnit.SECONDS)",
):
    if required not in text:
        fail(f"missing required implementation: {required}")

if "private fun shareNewsToFacebook(news: News)" in text:
    fail("shareNewsToFacebook is private but called by top-level NewsViewHolder")
if "private fun openNewsUrl(url: String)" in text:
    fail("openNewsUrl is private but called by top-level NewsViewHolder")

if text.count("{") != text.count("}") or text.count("(") != text.count(")"):
    fail("unbalanced Kotlin delimiters")

try:
    ET.parse(MANIFEST)
except ET.ParseError as exc:
    fail(f"AndroidManifest.xml is invalid XML: {exc}")

if 'id("com.android.application")' not in ROOT.joinpath("build.gradle.kts").read_text(encoding="utf-8"):
    fail("Android application plugin is missing")

print("SOURCE CHECK: OK")
print(f"Configured sources: {len(sources)}")
# MainActivity uses a local Int.dp() helper for programmatic category layout sizing.
main_activity = (ROOT / "app/src/main/java/com/golkoyhaber/app/MainActivity.kt").read_text(encoding="utf-8")
if ".dp()" in main_activity and "private fun Int.dp()" not in main_activity:
    raise SystemExit("MainActivity uses .dp() without defining the Int.dp() helper")
print("Kotlin/UI visibility checks: OK")
print("Manifest/XML check: OK")
