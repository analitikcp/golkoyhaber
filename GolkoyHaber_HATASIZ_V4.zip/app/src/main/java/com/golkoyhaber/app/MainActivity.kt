package com.golkoyhaber.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

data class News(
    val category: String,
    val title: String,
    val summary: String,
    val source: String,
    val url: String,
    val publishedAt: Date
)

private data class SourceConfig(
    val name: String,
    val url: String,
    val category: String,
    val host: String,
    val kind: String = "generic"
)

private data class SourceResult(
    val source: SourceConfig,
    val news: List<News>,
    val error: String? = null
)

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: NewsAdapter
    private lateinit var status: TextView
    private lateinit var pageTitle: TextView
    private lateinit var sourceStatus: TextView
    private val executor = Executors.newFixedThreadPool(8)
    private var allNews: List<News> = emptyList()
    private var isLoading = false

    private val sources = listOf(
        SourceConfig("Ordu Valiliği", "https://www.ordu.gov.tr/", "Resmî Kurumlar", "ordu.gov.tr"),
        SourceConfig("Gölköy Kaymakamlığı", "https://www.golkoy.gov.tr/haberler", "Gölköy", "golkoy.gov.tr"),
        SourceConfig("Gölköy Belediyesi", "https://www.golkoy.bel.tr/", "Gölköy", "golkoy.bel.tr"),
        SourceConfig("Gölköy İlçe Millî Eğitim", "https://golkoy.meb.gov.tr/", "Eğitim", "golkoy.meb.gov.tr"),
        SourceConfig("İHA Ordu", "https://www.iha.com.tr/ordu", "Ordu", "iha.com.tr", "iha"),
        SourceConfig("Haberler.com Ordu", "https://www.haberler.com/ordu/", "Ordu", "haberler.com", "haberler"),
        SourceConfig("DHA Ordu", "https://www.dha.com.tr/ordu-haber/", "Ordu", "dha.com.tr", "dha"),
        SourceConfig("Habertürk Yerel Ordu", "https://yerel-haberler.haberturk.com/ordu-haberleri", "Ordu", "haberturk.com", "haberturk"),
        SourceConfig("SonDakika.com Ordu", "https://www.sondakika.com/ordu/", "Ordu", "sondakika.com", "sondakika"),
        SourceConfig("NTV Ordu", "https://www.ntv.com.tr/haberleri/ordu", "Ordu", "ntv.com.tr", "ntv"),
        SourceConfig("CNN Türk Ordu", "https://www.cnnturk.com/ordu-haber/", "Ordu", "cnnturk.com", "cnnturk"),
        SourceConfig("Google News Ordu", "https://news.google.com/", "Ordu", "news.google.com", "google_news"),
        SourceConfig("Ordu Büyükşehir Belediyesi", "https://haber.ordu.bel.tr/", "Resmî Kurumlar", "ordu.bel.tr", "ordu_bel"),
        SourceConfig("TRT Haber Ordu", "https://www.trthaber.com/yerelhaberler/ordu/", "Ordu", "trthaber.com", "trt")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        val initialTop = root.paddingTop
        val initialBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = initialTop + bars.top, bottom = initialBottom + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        status = findViewById(R.id.status)
        pageTitle = findViewById(R.id.pageTitle)
        sourceStatus = findViewById(R.id.sourceStatus)

        adapter = NewsAdapter(emptyList())
        findViewById<RecyclerView>(R.id.newsList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            setHasFixedSize(false)
        }

        buildCategories()
        findViewById<Button>(R.id.refreshButton).setOnClickListener { loadNews() }
        findViewById<Button>(R.id.adminButton).setOnClickListener { showSourceInfo() }
        findViewById<Button>(R.id.facebookButton).setOnClickListener { openFacebookPage() }

        loadNews()
    }

    private fun loadNews() {
        if (isLoading) return
        isLoading = true
        status.text = "● ${sources.size} KAYNAK TARANIYOR"
        pageTitle.text = "Güncel Ordu / Gölköy Haberleri"
        sourceStatus.text = "Bugün + dün • Eski haberler gösterilmez"

        executor.execute {
            val jobs = sources.map { source ->
                executor.submit<SourceResult> {
                    try {
                        val direct = fetchDirect(source)
                        val rss = fetchViaGoogleNewsRss(source)
                        val merged = (direct + rss)
                            .filter { isRecent(it.publishedAt) }
                            .distinctBy { normalize(it.title) }
                            .sortedByDescending { it.publishedAt.time }
                            .take(15)
                        SourceResult(source, merged)
                    } catch (e: Exception) {
                        SourceResult(source, emptyList(), e.javaClass.simpleName)
                    }
                }
            }

            val results = jobs.map { job ->
                try { job.get() } catch (e: Exception) { SourceResult(sources[0], emptyList(), e.javaClass.simpleName) }
            }

            val fetched = results.flatMap { it.news }
                .filter { isRecent(it.publishedAt) }
                .distinctBy { normalize(it.title) }
                .sortedByDescending { it.publishedAt.time }
                .take(60)

            val okSources = results.count { it.news.isNotEmpty() }
            val totalFetched = results.sumOf { it.news.size }

            runOnUiThread {
                isLoading = false
                allNews = fetched
                adapter.submit(allNews)
                status.text = if (allNews.isEmpty()) "● HABER BULUNAMADI" else "● CANLI • ${allNews.size} HABER"
                sourceStatus.text = "$okSources/${sources.size} kaynak veri verdi • $totalFetched içerik bulundu • sadece bugün + dün"
                pageTitle.text = if (allNews.isEmpty()) "Haber bulunamadı" else "Gölköy / Ordu Gündem"
            }
        }
    }

    private fun fetchDirect(source: SourceConfig): List<News> {
        if (source.kind == "google_news") return emptyList()
        val doc = connect(source.url).get()
        val candidates = LinkedHashMap<String, Element>()

        for (a in doc.select("a[href], a[data-n-href], article a")) {
            val title = cleanText(a.text())
            val href = a.absUrl("href").ifBlank { a.absUrl("data-n-href") }
            if (!isCandidate(title, href, source)) continue
            if (title.length !in 18..220) continue
            candidates.putIfAbsent(normalize(title), a)
            if (candidates.size >= 30) break
        }

        val out = mutableListOf<News>()
        for ((_, anchor) in candidates) {
            if (out.size >= 15) break
            val title = cleanText(anchor.text())
            val href = anchor.absUrl("href").ifBlank { anchor.absUrl("data-n-href") }
            val published = extractPublishedDate(anchor) ?: continue
            if (!isRecent(published)) continue
            val summary = anchor.parent()?.text()?.let(::cleanText)
                ?.replace(title, "")?.trim()
                ?.takeIf { it.length >= 25 }
                ?: "Güncel haber. Haberin tamamını görüntülemek için dokunun."
            out += News(classify(source.category, title), title, summary.take(240), source.name, href, published)
        }
        return out
    }

    private fun fetchViaGoogleNewsRss(source: SourceConfig): List<News> {
        val query = if (source.kind == "google_news") "Ordu when:2d" else "site:${source.host} Ordu when:2d"
        val rssUrl = Uri.parse("https://news.google.com/rss/search")
            .buildUpon()
            .appendQueryParameter("q", query)
            .appendQueryParameter("hl", "tr")
            .appendQueryParameter("gl", "TR")
            .appendQueryParameter("ceid", "TR:tr")
            .build().toString()

        val doc = connect(rssUrl).get()
        val out = mutableListOf<News>()
        for (item in doc.select("item")) {
            if (out.size >= 15) break
            val title = cleanText(item.selectFirst("title")?.text().orEmpty())
            val href = cleanText(item.selectFirst("link")?.text().orEmpty())
            val date = parseDate(item.selectFirst("pubDate")?.text().orEmpty()) ?: continue
            val sourceElement = item.selectFirst("source")
            val originalHost = normalizeHost(sourceElement?.attr("url").orEmpty())
            if (source.kind != "google_news" && originalHost.isNotBlank() && !hostMatches(originalHost, source.host)) continue
            if (title.length < 12 || href.isBlank() || !isRecent(date)) continue
            val displayTitle = title.substringBefore(" - ").trim().ifBlank { title }
            out += News(
                classify(source.category, displayTitle),
                displayTitle,
                "Güncel haber. Haberin tamamını görüntülemek için dokunun.",
                source.name,
                href,
                date
            )
        }
        return out
    }

    private fun connect(url: String): org.jsoup.Connection =
        Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/154.0 Mobile Safari/537.36 GolkoyHaber/3.0")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.6")
            .header("Referer", "https://www.google.com/")
            .timeout(15_000)
            .followRedirects(true)
            .ignoreHttpErrors(true)
            .ignoreContentType(true)

    private fun extractPublishedDate(anchor: Element): Date? {
        val values = linkedSetOf<String>()
        values += anchor.attr("datetime")
        values += anchor.text()
        anchor.select("time").forEach { values += it.attr("datetime"); values += it.text() }
        anchor.parent()?.let { p ->
            values += p.text()
            p.select("time, [class*=date], [class*=time], [class*=tarih], [class*=yayin], [class*=publish]")
                .forEach { values += it.attr("datetime"); values += it.text() }
        }
        anchor.parent()?.parent()?.let { p -> values += p.text() }
        return values.asSequence().mapNotNull(::parseDate).firstOrNull()
    }

    private fun parseDate(raw: String): Date? {
        val text = cleanText(raw)
        if (text.isBlank()) return null

        // Many list pages place the relative timestamp next to the title,
        // e.g. "Haber başlığı 3 Saat Önce". Do not require the whole string
        // to consist only of the timestamp.
        Regex("(?i)\\b(\\d+)\\s*(dakika|dk)\\s*önce\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.MINUTE, -it.groupValues[1].toInt())
            }.time
        }
        Regex("(?i)\\b(\\d+)\\s*(saat)\\s*önce\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.HOUR_OF_DAY, -it.groupValues[1].toInt())
            }.time
        }
        Regex("(?i)\\b(\\d+)\\s*(gün)\\s*önce\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -it.groupValues[1].toInt())
            }.time
        }

        Regex("(?i)\\bbugün(?:\\s+(\\d{1,2}):(\\d{2}))?\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                it.groupValues.getOrNull(1)?.takeIf(String::isNotBlank)?.let { h ->
                    set(Calendar.HOUR_OF_DAY, h.toInt())
                }
                it.groupValues.getOrNull(2)?.takeIf(String::isNotBlank)?.let { m ->
                    set(Calendar.MINUTE, m.toInt())
                }
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.time
        }

        Regex("(?i)\\bdün(?:\\s+(\\d{1,2}):(\\d{2}))?\\b").find(text)?.let {
            return Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -1)
                it.groupValues.getOrNull(1)?.takeIf(String::isNotBlank)?.let { h ->
                    set(Calendar.HOUR_OF_DAY, h.toInt())
                }
                it.groupValues.getOrNull(2)?.takeIf(String::isNotBlank)?.let { m ->
                    set(Calendar.MINUTE, m.toInt())
                }
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.time
        }

        val rssPatterns = listOf(
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm Z",
            "dd MMM yyyy HH:mm:ss Z"
        )
        for (pattern in rssPatterns) {
            try {
                val f = SimpleDateFormat(pattern, Locale.ENGLISH).apply { isLenient = false }
                f.parse(text)?.let { return it }
            } catch (_: Exception) {
            }
        }

        val trMonths = "Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık"
        val patterns = listOf(
            Regex("\\b\\d{1,2}\\.\\d{1,2}\\.\\d{4}(?:\\s+\\d{1,2}:\\d{2})?"),
            Regex("\\b\\d{1,2}/\\d{1,2}/\\d{4}(?:\\s+\\d{1,2}:\\d{2})?"),
            Regex("\\b\\d{4}-\\d{2}-\\d{2}(?:[T ]\\d{1,2}:\\d{2}(?::\\d{2})?(?:Z|[+-]\\d{2}:?\\d{2})?)?"),
            Regex("\\b\\d{1,2}\\s+(?:$trMonths)\\s+\\d{4}(?:,?\\s+\\d{1,2}:\\d{2})?", RegexOption.IGNORE_CASE),
            Regex("\\b\\d{4}\\s+(?:$trMonths)\\s+\\d{1,2}(?:,?\\s+\\d{1,2}:\\d{2})?", RegexOption.IGNORE_CASE)
        )
        val formats = listOf(
            "dd.MM.yyyy HH:mm", "dd.MM.yyyy",
            "dd/MM/yyyy HH:mm", "dd/MM/yyyy",
            "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
            "dd MMMM yyyy, HH:mm", "dd MMMM yyyy HH:mm", "dd MMMM yyyy",
            "yyyy MMMM dd, HH:mm", "yyyy MMMM dd HH:mm", "yyyy MMMM dd"
        )

        for (regex in patterns) {
            val match = regex.find(text)?.value ?: continue
            for (format in formats) {
                try {
                    val f = SimpleDateFormat(format, Locale("tr", "TR")).apply { isLenient = false }
                    f.parse(match)?.let { return it }
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    private fun isRecent(date: Date): Boolean {
        val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val yesterday = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val c = Calendar.getInstance().apply { time = date }
        return !c.before(yesterday) && c.before(tomorrow)
    }

    private fun isCandidate(title: String, href: String, source: SourceConfig): Boolean {
        if (href.isBlank() || title.isBlank()) return false
        val lower = href.lowercase()
        if (lower.startsWith("mailto:") || lower.startsWith("javascript:") || lower.startsWith("tel:")) return false
        if (!hostMatches(normalizeHost(href), source.host)) return false
        val hints = listOf("haber", "gundem", "yerel", "ordu", "icerik", "duyuru", "basin", "etkinlik", "proje")
        return hints.any { lower.contains(it) } || title.contains("Ordu", true) || title.contains("Gölköy", true)
    }

    private fun hostMatches(actual: String, expected: String): Boolean {
        val a = normalizeHost(actual)
        val e = normalizeHost(expected)
        return a == e || a.endsWith(".$e") || e.endsWith(".$a")
    }

    private fun normalizeHost(value: String): String = try {
        val candidate = if (value.contains("://")) value else "https://$value"
        Uri.parse(candidate).host.orEmpty().removePrefix("www.").lowercase(Locale.ROOT)
    } catch (_: Exception) { value.substringAfter("://").substringBefore('/').removePrefix("www.").lowercase(Locale.ROOT) }

    private fun classify(base: String, title: String): String {
        if (base != "Resmî Kurumlar") return base
        val t = title.lowercase(Locale("tr", "TR"))
        return when {
            listOf("emniyet", "jandarma", "asayiş", "güvenlik", "trafik", "kaza", "operasyon").any { t.contains(it) } -> "Asayiş"
            listOf("sağlık", "hastane", "112", "doktor", "hasta").any { t.contains(it) } -> "Sağlık"
            listOf("meteoroloji", "yağış", "fırtına", "sel", "sıcaklık", "hava").any { t.contains(it) } -> "Hava"
            listOf("tarım", "fındık", "üretici", "çiftçi", "kokarca").any { t.contains(it) } -> "Tarım"
            listOf("spor", "şampiyon", "güreş", "futbol").any { t.contains(it) } -> "Spor"
            listOf("eğitim", "okul", "öğrenci", "öğretmen").any { t.contains(it) } -> "Eğitim"
            else -> "Resmî Kurumlar"
        }
    }

    private fun normalize(value: String): String = value.lowercase(Locale("tr", "TR"))
        .replace("ğ", "g").replace("ü", "u").replace("ş", "s").replace("ı", "i").replace("ö", "o").replace("ç", "c")
        .replace(Regex("[^a-z0-9 ]"), "").replace(Regex("\\s+"), " ").trim()

    private fun cleanText(value: String): String = value.replace(Regex("\\s+"), " ").trim()

    private fun buildCategories() {
        val bar = findViewById<GridLayout>(R.id.categoryBar)
        val categories = listOf("Tümü", "Gölköy", "Resmî", "Asayiş", "Eğitim", "Sağlık", "Spor", "Tarım", "Hava", "Vefat")
        categories.forEach { category ->
            val button = MaterialButton(this).apply {
                text = category
                isAllCaps = false
                minHeight = 40
                minimumHeight = 40
                setTextSize(12f)
                setPadding(2, 0, 2, 0)
                setOnClickListener {
                    val filtered = when (category) {
                        "Tümü" -> allNews
                        "Gölköy" -> allNews.filter { it.category == "Gölköy" }
                        "Resmî" -> allNews.filter { it.category == "Resmî Kurumlar" }
                        else -> allNews.filter { it.category.contains(category, true) }
                    }
                    adapter.submit(filtered)
                    pageTitle.text = if (category == "Tümü") "Gölköy / Ordu Gündem" else "$category Haberleri"
                }
            }
            val params = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                height = 42
                setMargins(2, 2, 2, 2)
            }
            bar.addView(button, params)
        }
    }

    private fun showSourceInfo() {
        AlertDialog.Builder(this)
            .setTitle("Kaynak Durumu")
            .setMessage("14 kaynak kontrol ediliyor…")
            .setPositiveButton("Kapat", null)
            .show()

        executor.execute {
            val counts = sources.map { source ->
                try {
                    fetchViaGoogleNewsRss(source)
                        .count { isRecent(it.publishedAt) }
                } catch (_: Exception) {
                    0
                }
            }

            runOnUiThread {
                val lines = sources.mapIndexed { index, source ->
                    "• ${source.name}: ${counts[index]}"
                }
                val dialog = AlertDialog.Builder(this)
                    .setTitle("Kaynak Durumu — bugün + dün")
                    .setMessage(
                        lines.joinToString("\n") +
                            "\n\nEski tarihli veya tarihi doğrulanamayan içerikler gösterilmez." +
                            "\n\nNot: Bazı siteler doğrudan erişimi engellerse Google News RSS yedeği kullanılır."
                    )
                    .setPositiveButton("Kapat", null)
                    .create()
                dialog.show()
            }
        }
    }

    private fun openFacebookPage() = safeOpenUrl("https://www.facebook.com/habergolkoy52")

    private fun shareNewsToFacebook(news: News) {
        val shareText = "GölköyHaber | ${news.title}\n\n${news.url}"
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, news.title)
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(send, "Haberi paylaş"))
        } catch (_: Exception) {
            Toast.makeText(this, "Paylaşım menüsü açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openNewsUrl(url: String) = safeOpenUrl(url)

    private fun safeOpenUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            if (intent.resolveActivity(packageManager) != null) startActivity(intent)
            else Toast.makeText(this, "Bağlantıyı açacak uygulama bulunamadı.", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Bağlantı açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}

private class NewsAdapter(private var items: List<News>) : RecyclerView.Adapter<NewsViewHolder>() {
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): NewsViewHolder =
        NewsViewHolder(android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent, false))
    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size
    private fun submit(newItems: List<News>) { items = newItems; notifyDataSetChanged() }
}

private class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    fun bind(news: News) {
        itemView.findViewById<TextView>(R.id.category).text = news.category.uppercase(Locale("tr", "TR"))
        itemView.findViewById<TextView>(R.id.title).text = news.title
        itemView.findViewById<TextView>(R.id.summary).text = news.summary
        itemView.findViewById<TextView>(R.id.source).text = "${news.source} • ${formatTime(news.publishedAt)}"
        itemView.findViewById<Button>(R.id.shareFacebookButton).setOnClickListener { (itemView.context as? MainActivity)?.shareNewsToFacebook(news) }
        itemView.setOnClickListener { (itemView.context as? MainActivity)?.openNewsUrl(news.url) }
    }

    private fun formatTime(date: Date): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(date)
}
