# GölköyHaber 2.0

Gölköy ve Ordu için güncel haber akışı.

## Kaynaklar

Mevcut 4 kaynağa ek olarak 10 yeni kaynak tanımlıdır; toplam 14 kaynak vardır.

## Tarih kuralı

- Yalnızca **bugün** ve **dün** yayımlanan içerikler gösterilir.
- Eski tarihli içerikler gösterilmez.
- Yayın tarihi doğrulanamayan içerikler gösterilmez.
- Gelecek tarihli içerikler gösterilmez.
- `Bugün`, `Dün`, `X saat önce`, `X dakika önce` ve yaygın tarih biçimleri desteklenir.

## Veri toplama

Her kaynak için doğrudan sayfa taraması denenir. Doğrudan erişim 403/robots/CDN nedeniyle başarısız olursa Google News RSS yedeği kullanılır. RSS sonuçlarında da kaynak alan adı ve tarih kontrol edilir.

## Uygulama

- 14 kaynak paralel taranır.
- Aynı başlıktaki içerikler tekilleştirilir.
- En fazla 60 haber gösterilir.
- Kaynak Durumu ekranı kaynak başına kaç güncel içerik bulunduğunu gösterir.
- Haber kartına dokunmak bağlantıyı güvenli şekilde açar.
- Paylaş butonu Android'in standart paylaşım ekranını açar; uygulama bulunamazsa uygulama kapanmaz.
- Sistem çubuğu insets'leri nedeniyle alt menü navigasyon çubuğunun altında kalmaz.

## Derleme

GitHub Actions `build-apk.yml` dosyası Java 17 + Gradle 8.10.2 ile doğrudan `:app:assembleDebug` çalıştırır.


## 2.0.1 build fix
- `News`, `SourceConfig` and `SourceResult` are file-private implementation types.
- `shareNewsToFacebook(news: News)` and `openNewsUrl(url: String)` are private Activity helpers.
- No public Activity method exposes a file-private model.
- Relative timestamps embedded in surrounding text (`3 Saat Önce`, `20 Dakika Önce`, `Dün 17:30`, `Bugün 09:20`) are parsed.
- Source status loading is performed off the UI thread so the button does not freeze the screen.
- Version: 2.0.1 / versionCode 5.

## Verification note
Bu teslimatta kaynak kodu satır bazında statik olarak kontrol edildi ve mevcut GitHub Actions workflow'una kaynak bütünlüğü kontrolü eklendi. Bu çalışma ortamında Android SDK/Gradle kurulumu bulunmadığından burada gerçek `:app:assembleDebug` çalıştırılamadı; bu nedenle APK'nın yerel ortamda derlendiği iddia edilmemektedir. GitHub Actions aynı kaynak üzerinde önce `SOURCE CHECK: OK`, ardından `:app:assembleDebug` çalıştıracaktır.
