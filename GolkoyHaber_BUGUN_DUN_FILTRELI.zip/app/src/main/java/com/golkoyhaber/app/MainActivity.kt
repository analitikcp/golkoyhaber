package com.golkoyhaber.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import org.jsoup.Jsoup
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

private data class News(
    val category: String,
    val title: String,
    val summary: String,
    val source: String,
    val url: String,
    val publishedAt: Date
)

private data class SourceConfig(
    val name: String,
    val url: String,
    val category: String,
    val host: String
)

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: NewsAdapter
    private lateinit var status: TextView
    private val executor = Executors.newFixedThreadPool(4)
    private var allNews: List<News> = emptyList()

    private val sources = listOf(
        SourceConfig("Ordu Valiliği", "https://www.ordu.gov.tr/", "Resmî Kurumlar", "ordu.gov.tr"),
        SourceConfig("Gölköy Kaymakamlığı", "https://www.golkoy.gov.tr/haberler", "Gölköy", "golkoy.gov.tr"),
        SourceConfig("Gölköy Belediyesi", "https://www.golkoy.bel.tr/", "Gölköy", "golkoy.bel.tr"),
        SourceConfig("Gölköy İlçe Millî Eğitim", "https://golkoy.meb.gov.tr/", "Eğitim", "golkoy.meb.gov.tr")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        adapter = NewsAdapter(emptyList())
        findViewById<RecyclerView>(R.id.newsList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        buildCategories()
        findViewById<Button>(R.id.adminButton).setOnClickListener { showSourceInfo() }
        findViewById<Button>(R.id.facebookButton).setOnClickListener { openFacebookPage() }
        findViewById<Button>(R.id.refreshButton).setOnClickListener { loadNews() }

        loadNews()
    }

    private fun loadNews() {
        status.text = "● HABERLER ÇEKİLİYOR"
        status.alpha = 0.9f

        executor.execute {
            val fetched = mutableListOf<News>()
            sources.forEach { source ->
                try {
                    fetched += fetchSource(source)
                } catch (_: Exception) {
                    // Bir kaynak erişilemezse diğer kaynakların akışı devam eder.
                }
            }

            val unique = fetched
                .distinctBy { normalize(it.title) }
                .sortedByDescending { it.publishedAt.time }
                .take(60)

            runOnUiThread {
                allNews = unique
                adapter.submit(allNews)
                status.text = if (allNews.isEmpty()) "● BAĞLANTI YOK" else "● CANLI • ${allNews.size} HABER"
                findViewById<TextView>(R.id.pageTitle).text =
                    if (allNews.isEmpty()) "Haber alınamadı" else "Gölköy / Ordu Gündem"
            }
        }
    }

    private fun fetchSource(source: SourceConfig): List<News> {
        val doc = Jsoup.connect(source.url)
            .userAgent("Mozilla/5.0 (Android) GolkoyHaber/1.0")
            .timeout(15_000)
            .followRedirects(true)
            .get()

        val result = LinkedHashMap<String, News>()
        for (a in doc.select("a[href]")) {
            val title = a.text().replace(Regex("\\s+"), " ").trim()
            val href = a.absUrl("href")
            if (!isCandidate(title, href, source)) continue
            if (title.length < 18 || title.length > 220) continue

            // Sadece bugün ve dün yayımlanan içerikleri kabul ediyoruz.
            // Tarihi bulunamayan içerik güvenli tarafta kalmak için elenir; böylece
            // kurum sitelerinin eski proje/duyuru arşivleri haber akışına karışmaz.
            val publishedAt = extractPublishedDate(a) ?: continue
            if (!isRecent(publishedAt)) continue

            val key = normalize(title)
            if (result.containsKey(key)) continue

            val parentText = a.parent()?.text()?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
            val summary = parentText
                .replace(title, "")
                .trim()
                .takeIf { it.length >= 25 && it != title }
                ?: "Kaynak sayfasındaki güncel içerik. Haberin tamamını görüntülemek için dokunun."

            result[key] = News(
                category = classify(source.category, title),
                title = title,
                summary = summary.take(240),
                source = source.name,
                url = href,
                publishedAt = publishedAt
            )

            if (result.size >= 15) break
        }
        return result.values.toList()
    }

    private fun extractPublishedDate(anchor: org.jsoup.nodes.Element): Date? {
        val candidates = linkedSetOf<String>()

        // Linkin kendisi ve yakın kapsayıcılar: mevcut kaynaklarda tarih çoğunlukla
        // başlığın yanında veya aynı kart/listede bulunuyor.
        candidates += anchor.text()
        anchor.parent()?.let { parent ->
            candidates += parent.text()
            parent.select("time[datetime]").forEach { candidates += it.attr("datetime") }
            parent.parent()?.let { grandParent ->
                candidates += grandParent.text()
                grandParent.select("time[datetime]").forEach { candidates += it.attr("datetime") }
            }
        }
        anchor.select("time[datetime]").forEach { candidates += it.attr("datetime") }
        anchor.parents().take(3).forEach { ancestor ->
            ancestor.select("time[datetime]").forEach { candidates += it.attr("datetime") }
        }

        for (text in candidates) {
            parseDate(text)?.let { return it }
        }
        return null
    }

    private fun parseDate(raw: String): Date? {
        val text = raw.replace(Regex("\\s+"), " ").trim()
        val patterns = listOf(
            "dd.MM.yyyy HH:mm", "dd.MM.yyyy",
            "dd/MM/yyyy HH:mm", "dd/MM/yyyy",
            "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
            "dd MMMM yyyy, HH:mm", "dd MMMM yyyy HH:mm", "dd MMMM yyyy",
            "yyyy MMMM dd, HH:mm", "yyyy MMMM dd HH:mm", "yyyy MMMM dd"
        )
        for (pattern in patterns) {
            try {
                val parser = SimpleDateFormat(pattern, Locale("tr", "TR"))
                parser.isLenient = false
                val match = Regex(
                    when {
                        pattern.startsWith("dd.MM") -> "\\b\\d{1,2}\\.\\d{1,2}\\.\\d{4}(?:\\s+\\d{1,2}:\\d{2})?"
                        pattern.startsWith("dd/MM") -> "\\b\\d{1,2}/\\d{1,2}/\\d{4}(?:\\s+\\d{1,2}:\\d{2})?"
                        pattern.startsWith("yyyy-MM-dd") -> "\\b\\d{4}-\\d{2}-\\d{2}(?:[T ]\\d{1,2}:\\d{2}(?::\\d{2})?)?"
                        pattern.startsWith("yyyy MMMM") -> "\\b\\d{4}\\s+(?:Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık)\\s+\\d{1,2}(?:,?\\s+\\d{1,2}:\\d{2})?"
                        else -> "\\b\\d{1,2}\\s+(?:Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık)\\s+\\d{4}(?:,?\\s+\\d{1,2}:\\d{2})?"
                    }
                ).find(text)?.value ?: continue
                return parser.parse(match)
            } catch (_: Exception) {
                // Diğer tarih biçimini dene.
            }
        }
        return null
    }

    private fun isRecent(date: Date): Boolean {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val yesterday = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val candidate = Calendar.getInstance().apply { time = date }

        // Takvim günü bazlı filtre: bugün + dün. Gelecek tarihli içerikleri de alma.
        return !candidate.before(yesterday) && candidate.before(tomorrow)
    }

    private fun isCandidate(title: String, href: String, source: SourceConfig): Boolean {
        if (href.isBlank() || !href.contains(source.host)) return false
        val lower = href.lowercase()
        if (lower.startsWith("mailto:") || lower.startsWith("javascript:")) return false
        if (title.equals("Anasayfa", true) || title.equals("Tümü", true)) return false

        val pathHint = listOf("haber", "icerik", "duyuru", "ilan", "basin", "etkinlik", "proje")
        return pathHint.any { lower.contains(it) } ||
            title.contains("haber", true) ||
            title.contains("duyuru", true) ||
            title.contains("mesaj", true)
    }


    private fun classify(baseCategory: String, title: String): String {
        if (baseCategory != "Resmî Kurumlar") return baseCategory
        val t = title.lowercase()
        return when {
            listOf("emniyet", "jandarma", "asayiş", "güvenlik", "trafik", "kaza", "operasyon").any { t.contains(it) } -> "Asayiş"
            listOf("sağlık", "hastane", "112", "doktor", "hasta").any { t.contains(it) } -> "Sağlık"
            listOf("meteoroloji", "yağış", "fırtına", "sel", "sıcaklık", "hava").any { t.contains(it) } -> "Hava"
            listOf("tarım", "fındık", "üretici", "çiftçi", "kokarca").any { t.contains(it) } -> "Tarım"
            listOf("spor", "şampiyon", "güreş", "futbol").any { t.contains(it) } -> "Spor"
            listOf("eğitim", "okul", "öğrenci", "öğretmen").any { t.contains(it) } -> "Eğitim"
            else -> "Resmî Kurumlar"
        }
    }

    private fun normalize(value: String): String =
        value.lowercase()
            .replace("ğ", "g").replace("ü", "u").replace("ş", "s")
            .replace("ı", "i").replace("ö", "o").replace("ç", "c")
            .replace(Regex("[^a-z0-9 ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun buildCategories() {
        val bar = findViewById<LinearLayout>(R.id.categoryBar)
        val categories = listOf("Tümü", "Gölköy", "Resmî", "Asayiş", "Eğitim", "Sağlık", "Spor", "Tarım", "Siyaset", "Hava", "Vefat")
        categories.forEach { category ->
            val button = MaterialButton(this).apply {
                text = category
                isAllCaps = false
                setOnClickListener {
                    val filtered = when (category) {
                        "Tümü" -> allNews
                        "Gölköy" -> allNews.filter { it.category == "Gölköy" }
                        "Resmî" -> allNews.filter { it.category == "Resmî Kurumlar" }
                        else -> allNews.filter { it.category.contains(category, ignoreCase = true) }
                    }
                    adapter.submit(filtered)
                    findViewById<TextView>(R.id.pageTitle).text =
                        if (category == "Tümü") "Gölköy / Ordu Gündem" else category
                }
            }
            bar.addView(button)
        }
    }

    private fun showSourceInfo() {
        AlertDialog.Builder(this)
            .setTitle("GölköyHaber kaynak merkezi")
            .setMessage(
                "Canlı kaynaklar:\n\n" +
                    sources.joinToString("\n") { "• ${it.name}" } +
                    "\n\nHaberler uygulama açılışında internetten çekilir.\n" +
                    "Aynı başlığa sahip içerikler tekilleştirilir.\n" +
                    "Sadece bugün ve dünden yayımlanan, tarihi tespit edilebilen içerikler gösterilir.\n\n" +
                    "Daha sonraki aşamada merkezi backend, editör onayı ve Facebook Sayfası yayın sistemi eklenebilir."
            )
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun openFacebookPage() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/habergolkoy52")))
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}

private class NewsAdapter(private var items: List<News>) : RecyclerView.Adapter<NewsViewHolder>() {
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): NewsViewHolder {
        val view = android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent, false)
        return NewsViewHolder(view)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size
    fun submit(newItems: List<News>) { items = newItems; notifyDataSetChanged() }
}

private class NewsViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
    fun bind(news: News) {
        itemView.findViewById<TextView>(R.id.category).text = news.category.uppercase()
        itemView.findViewById<TextView>(R.id.title).text = news.title
        itemView.findViewById<TextView>(R.id.summary).text = news.summary
        itemView.findViewById<TextView>(R.id.source).text = "Kaynak: ${news.source}"
        itemView.setOnClickListener {
            itemView.context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(news.url)))
        }
    }
}
